# Experiment Data Pack

Compact tables and summaries for the phone-timed and sampled pixel evaluations.

## Contents

- `phone-timing/opencv-phone-results.json` — Recorded OpenCV phone timing entries.
- `phone-timing/comparison-results.json` — Combined OpenCV and CNN timing summary.
- `phone-timing/original-report.md` — Original comparison report.
- `phone-timing/english-report.md` — English reading edition.
- `pixel-evaluation/annotation-samples.csv` — Selected reviewed annotation samples.
- `pixel-evaluation/pixel-annotations.csv` — Frame-level pixel annotation table; retained filename described in package guide.
- `pixel-evaluation/pixel-summary.json` — Per-run statistical summary; retained source is marked draft in the archive.
- `pixel-evaluation/six-run-audit.json` — Six-run inclusion and audit record.
- `pixel-evaluation/original-reviewed-report.md` — Original reviewed result report.
- `pixel-evaluation/english-reviewed-report.md` — English reading edition of the reviewed result.

## Reading notes

- English report editions are provided for accessibility. The original Chinese records remain included when relevant.
- Review the limitations stated in each report before comparing methods.
- This package contains selected research material. The website archive retains the complete provenance record.
