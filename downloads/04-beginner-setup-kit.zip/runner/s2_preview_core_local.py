"""Experimental v2 boundary checks; static servo validation only."""
import ast
import cv2
import numpy as np
_SCOPE = {'cv2': cv2, 'np': np}
for source, names in [('#!/usr/bin/env python3\n"""\nRun the OpenCV lane-following baseline directly on the Raspberry Pi car.\n\nThis is a cautious test script:\n  - camera frames are processed with ROI + Canny + Hough\n  - steering is generated from estimated lane-center error\n  - throttle is a fixed low PWM value\n  - throttle is stopped if lane detection is lost\n  - Ctrl+C sends stopped throttle and centered steering\n"""\n\nfrom __future__ import annotations\n\nimport argparse\nimport time\nfrom pathlib import Path\n\nimport cv2\nimport numpy as np\nfrom Adafruit_PCA9685 import PCA9685\nfrom picamera2 import Picamera2\n\n\nSTEERING_LEFT_PWM = 440\nSTEERING_CENTER_PWM = 350\nSTEERING_RIGHT_PWM = 290\nTHROTTLE_STOPPED_PWM = 370\n\n\ndef preprocess(frame: np.ndarray, roi_top_ratio: float) -> tuple[np.ndarray, np.ndarray]:\n    height, width = frame.shape[:2]\n    roi_top = int(height * roi_top_ratio)\n    roi = frame[roi_top:height, 0:width]\n    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)\n    blur = cv2.GaussianBlur(gray, (5, 5), 0)\n    edges = cv2.Canny(blur, 60, 160)\n    return roi, edges\n\n\ndef build_color_masks(roi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:\n    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)\n    white_mask = cv2.inRange(hsv, np.array([0, 0, 145]), np.array([179, 80, 255]))\n    yellow_mask = cv2.inRange(hsv, np.array([15, 60, 80]), np.array([40, 255, 255]))\n    kernel = np.ones((3, 3), np.uint8)\n    white_mask = cv2.morphologyEx(white_mask, cv2.MORPH_OPEN, kernel)\n    yellow_mask = cv2.morphologyEx(yellow_mask, cv2.MORPH_OPEN, kernel)\n    # White closing disabled\n    yellow_mask = cv2.morphologyEx(yellow_mask, cv2.MORPH_CLOSE, kernel)\n    return white_mask, yellow_mask\n\n\ndef median_x_near_bottom(mask: np.ndarray, side: str, bottom_ratio: float) -> int | None:\n    height, width = mask.shape[:2]\n    y0 = int(height * bottom_ratio)\n    ys, xs = np.where(mask[y0:height, :] > 0)\n    if xs.size < 8:\n        return None\n    if side == "left":\n        xs = xs[xs < width * 0.65]\n    elif side == "right":\n        xs = xs[xs > width * 0.35]\n    if xs.size < 8:\n        return None\n    return int(np.median(xs))\n\n\ndef detect_outer_lane_color(\n    frame: np.ndarray,\n    roi_top_ratio: float,\n    lane_side: str,\n    bottom_ratio: float,\n    fallback_lane_width_ratio: float,\n    target_offset_px: int,\n) -> tuple[int | None, int, dict]:\n    height, width = frame.shape[:2]\n    roi_top = int(height * roi_top_ratio)\n    roi = frame[roi_top:height, :]\n    white_mask, yellow_mask = build_color_masks(roi)\n\n    if lane_side == "left":\n        white_side = "left"\n        yellow_side = "right"\n        fallback_sign = 1\n    else:\n        white_side = "right"\n        yellow_side = "left"\n        fallback_sign = -1\n\n    white_x = median_x_near_bottom(white_mask, white_side, bottom_ratio)\n    yellow_x = median_x_near_bottom(yellow_mask, yellow_side, bottom_ratio)\n    fallback_lane_width = int(width * fallback_lane_width_ratio)\n\n    if white_x is not None and yellow_x is not None:\n        target_x = int((white_x + yellow_x) / 2)\n    elif white_x is not None:\n        target_x = white_x + fallback_sign * fallback_lane_width // 2\n    elif yellow_x is not None:\n        target_x = yellow_x - fallback_sign * fallback_lane_width // 2\n    else:\n        target_x = None\n\n    if target_x is not None:\n        target_x += target_offset_px\n        target_x = max(0, min(width - 1, target_x))\n\n    debug_info = {\n        "roi_top": roi_top,\n        "white_mask": white_mask,\n        "yellow_mask": yellow_mask,\n        "white_x": white_x,\n        "yellow_x": yellow_x,\n    }\n    detected_count = int(white_x is not None) + int(yellow_x is not None)\n    return target_x, detected_count, debug_info\n\n\ndef detect_lines(edges: np.ndarray) -> np.ndarray | None:\n    return cv2.HoughLinesP(\n        edges,\n        rho=1,\n        theta=np.pi / 180,\n        threshold=35,\n        minLineLength=35,\n        maxLineGap=25,\n    )\n\n\ndef estimate_lane_center(lines: np.ndarray | None, width: int, height: int) -> tuple[int | None, int]:\n    if lines is None:\n        return None, 0\n\n    left_x: list[int] = []\n    right_x: list[int] = []\n    y_eval = height - 1\n\n    for line in lines:\n        x1, y1, x2, y2 = line[0]\n        dx = x2 - x1\n        dy = y2 - y1\n        if dx == 0:\n            continue\n\n        slope = dy / dx\n        if abs(slope) < 0.35:\n            continue\n\n        intercept = y1 - slope * x1\n        x_at_bottom = int((y_eval - intercept) / slope)\n        if x_at_bottom < 0 or x_at_bottom >= width:\n            continue\n\n        if slope < 0:\n            left_x.append(x_at_bottom)\n        else:\n            right_x.append(x_at_bottom)\n\n    lane_width_guess = int(width * 0.55)\n    if left_x and right_x:\n        lane_center = int((np.median(left_x) + np.median(right_x)) / 2)\n    elif left_x:\n        lane_center = int(np.median(left_x) + lane_width_guess / 2)\n    elif right_x:\n        lane_center = int(np.median(right_x) - lane_width_guess / 2)\n    else:\n        return None, len(lines)\n\n    return max(0, min(width - 1, lane_center)), len(lines)\n\n\ndef compute_steering(lane_center_x: int | None, frame_center_x: int, width: int, gain: float) -> float:\n    if lane_center_x is None:\n        return 0.0\n    error_px = lane_center_x - frame_center_x\n    normalized_error = error_px / (width / 2)\n    return float(np.clip(gain * normalized_error, -1.0, 1.0))\n\n\ndef draw_debug(\n    frame: np.ndarray,\n    roi_top_ratio: float,\n    lines: np.ndarray | None,\n    lane_center_x: int | None,\n    steering: float,\n    throttle_pwm: int,\n    line_count: int,\n) -> np.ndarray:\n    debug = frame.copy()\n    height, width = frame.shape[:2]\n    roi_top = int(height * roi_top_ratio)\n    frame_center_x = width // 2\n\n    cv2.rectangle(debug, (0, roi_top), (width - 1, height - 1), (0, 255, 255), 2)\n    if lines is not None:\n        for line in lines:\n            x1, y1, x2, y2 = line[0]\n            cv2.line(debug, (x1, y1 + roi_top), (x2, y2 + roi_top), (0, 255, 0), 2)\n\n    cv2.line(debug, (frame_center_x, roi_top), (frame_center_x, height), (255, 0, 0), 2)\n    if lane_center_x is not None:\n        cv2.line(debug, (lane_center_x, roi_top), (lane_center_x, height), (0, 0, 255), 2)\n\n    text = f"steer={steering:+.2f} throttle={throttle_pwm} lines={line_count}"\n    cv2.putText(debug, text, (5, 18), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)\n    return debug\n\n\ndef draw_color_debug(\n    frame: np.ndarray,\n    debug_info: dict,\n    target_x: int | None,\n    steering: float,\n    throttle_pwm: int,\n    detected_count: int,\n) -> np.ndarray:\n    debug = frame.copy()\n    height, width = frame.shape[:2]\n    roi_top = debug_info["roi_top"]\n    frame_center_x = width // 2\n\n    cv2.rectangle(debug, (0, roi_top), (width - 1, height - 1), (0, 255, 255), 2)\n    cv2.line(debug, (frame_center_x, roi_top), (frame_center_x, height), (255, 0, 0), 2)\n    if debug_info["white_x"] is not None:\n        cv2.line(debug, (debug_info["white_x"], roi_top), (debug_info["white_x"], height), (255, 255, 255), 2)\n    if debug_info["yellow_x"] is not None:\n        cv2.line(debug, (debug_info["yellow_x"], roi_top), (debug_info["yellow_x"], height), (0, 255, 255), 2)\n    if target_x is not None:\n        cv2.line(debug, (target_x, roi_top), (target_x, height), (0, 0, 255), 2)\n\n    white_bgr = cv2.cvtColor(debug_info["white_mask"], cv2.COLOR_GRAY2BGR)\n    yellow_bgr = cv2.cvtColor(debug_info["yellow_mask"], cv2.COLOR_GRAY2BGR)\n    yellow_bgr[:, :, 0] = 0\n    mask_view = cv2.addWeighted(white_bgr, 0.7, yellow_bgr, 0.7, 0)\n    mask_view = cv2.resize(mask_view, (width // 3, height // 3))\n    debug[height - mask_view.shape[0] : height, 0 : mask_view.shape[1]] = mask_view\n\n    text = f"target={target_x} steer={steering:+.2f} throttle={throttle_pwm} marks={detected_count}"\n    cv2.putText(debug, text, (5, 18), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (255, 255, 255), 1)\n    return debug\n\n\ndef steering_to_pwm(steering: float, max_steering: float, center_pwm: int) -> int:\n    steering = float(np.clip(steering, -max_steering, max_steering))\n    if steering < 0:\n        return int(center_pwm + (-steering / max_steering) * (STEERING_LEFT_PWM - center_pwm))\n    if steering > 0:\n        return int(center_pwm + (steering / max_steering) * (STEERING_RIGHT_PWM - center_pwm))\n    return center_pwm\n\n\ndef set_pwm(pwm: PCA9685, steering_pwm: int, throttle_pwm: int) -> None:\n    pwm.set_pwm(1, 0, steering_pwm)\n    pwm.set_pwm(0, 0, throttle_pwm)\n\n\ndef safe_set_pwm(\n    pwm: PCA9685,\n    steering_pwm: int,\n    throttle_pwm: int,\n    retries: int = 2,\n) -> PCA9685:\n    for attempt in range(retries + 1):\n        try:\n            set_pwm(pwm, steering_pwm, throttle_pwm)\n            return pwm\n        except OSError as exc:\n            print(f"I2C write failed attempt {attempt + 1}/{retries + 1}: {exc}")\n            time.sleep(0.05)\n            pwm = init_pwm_with_retry(retries=2, delay=0.1)\n    return pwm\n\n\ndef init_pwm_with_retry(retries: int = 5, delay: float = 0.5) -> PCA9685:\n    last_error: Exception | None = None\n    for attempt in range(1, retries + 1):\n        try:\n            pwm = PCA9685(address=0x40, busnum=1)\n            pwm.set_pwm_freq(60)\n            return pwm\n        except OSError as exc:\n            last_error = exc\n            print(f"PCA9685 init failed attempt {attempt}/{retries}: {exc}")\n            time.sleep(delay)\n    raise RuntimeError("Could not initialize PCA9685 on I2C bus 1 address 0x40") from last_error\n\n\ndef parse_args() -> argparse.Namespace:\n    parser = argparse.ArgumentParser(description="OpenCV lane follower on Raspberry Pi car")\n    parser.add_argument("--detector", choices=["hough", "color"], default="color")\n    parser.add_argument("--lane-side", choices=["left", "right"], default="left")\n    parser.add_argument("--throttle-pwm", type=int, default=400, help="Low forward throttle PWM")\n    parser.add_argument("--duration", type=float, default=20.0, help="Maximum run time in seconds")\n    parser.add_argument("--roi-top", type=float, default=0.55)\n    parser.add_argument("--bottom-ratio", type=float, default=0.45)\n    parser.add_argument("--fallback-lane-width", type=float, default=0.42)\n    parser.add_argument("--target-offset-px", type=int, default=0, help="Shift target lane center left/right in pixels")\n    parser.add_argument("--steering-gain", type=float, default=0.8)\n    parser.add_argument("--max-steering", type=float, default=0.7)\n    parser.add_argument("--steering-center-pwm", type=int, default=STEERING_CENTER_PWM)\n    parser.add_argument("--throttle-ramp", type=float, default=2.0, help="Seconds to ramp from stopped to target throttle")\n    parser.add_argument("--loop-hz", type=float, default=20.0, help="Control loop rate limit")\n    parser.add_argument("--invert-steering", action="store_true", help="Reverse OpenCV steering direction")\n    parser.add_argument("--debug-dir", help="Optional directory for saved debug frames")\n    parser.add_argument("--debug-every", type=int, default=10, help="Save one debug frame every N frames")\n    parser.add_argument("--lost-stop", action="store_true", default=True, help="Stop throttle when lane is lost")\n    parser.add_argument("--width", type=int, default=160)\n    parser.add_argument("--height", type=int, default=120)\n    return parser.parse_args()\n\n\ndef main() -> None:\n    args = parse_args()\n\n    pwm = init_pwm_with_retry()\n    pwm = safe_set_pwm(pwm, args.steering_center_pwm, THROTTLE_STOPPED_PWM)\n\n    camera = Picamera2()\n    config = camera.create_preview_configuration(\n        main={"size": (args.width, args.height), "format": "BGR888"}\n    )\n    camera.configure(config)\n    camera.start()\n    time.sleep(1.0)\n\n    print("OpenCV car test starting in 3 seconds. Keep one hand ready to lift/stop the car.")\n    for remaining in (3, 2, 1):\n        print(f"{remaining}...")\n        time.sleep(1.0)\n\n    start = time.perf_counter()\n    frame_count = 0\n    total_frames = 0\n    last_log = start\n    debug_dir = Path(args.debug_dir) if args.debug_dir else None\n    if debug_dir:\n        debug_dir.mkdir(parents=True, exist_ok=True)\n\n    try:\n        while time.perf_counter() - start < args.duration:\n            loop_start = time.perf_counter()\n            frame = camera.capture_array()\n            lines = None\n            debug_info = None\n            if args.detector == "color":\n                lane_center_x, line_count, debug_info = detect_outer_lane_color(\n                    frame,\n                    args.roi_top,\n                    args.lane_side,\n                    args.bottom_ratio,\n                    args.fallback_lane_width,\n                    args.target_offset_px,\n                )\n            else:\n                roi, edges = preprocess(frame, args.roi_top)\n                lines = detect_lines(edges)\n                lane_center_x, line_count = estimate_lane_center(lines, roi.shape[1], roi.shape[0])\n            steering = compute_steering(lane_center_x, frame.shape[1] // 2, frame.shape[1], args.steering_gain)\n            if args.invert_steering:\n                steering *= -1.0\n            steering_pwm = steering_to_pwm(steering, args.max_steering, args.steering_center_pwm)\n            if lane_center_x is not None:\n                run_elapsed = time.perf_counter() - start\n                ramp = 1.0 if args.throttle_ramp <= 0 else min(1.0, run_elapsed / args.throttle_ramp)\n                throttle_pwm = int(THROTTLE_STOPPED_PWM + (args.throttle_pwm - THROTTLE_STOPPED_PWM) * ramp)\n            else:\n                throttle_pwm = THROTTLE_STOPPED_PWM\n\n            pwm = safe_set_pwm(pwm, steering_pwm, throttle_pwm)\n            frame_count += 1\n            total_frames += 1\n\n            if debug_dir and total_frames % args.debug_every == 0:\n                if args.detector == "color":\n                    debug = draw_color_debug(\n                        frame, debug_info, lane_center_x, steering,\n                        throttle_pwm, line_count\n                    )\n                else:\n                    debug = draw_debug(\n                        frame, args.roi_top, lines, lane_center_x,\n                        steering, throttle_pwm, line_count\n                    )\n                cv2.imwrite(str(debug_dir / f"frame_{total_frames:05d}.jpg"), debug)\n\n            now = time.perf_counter()\n            if now - last_log >= 1.0:\n                fps = frame_count / (now - last_log)\n                frame_count = 0\n                last_log = now\n                print(\n                    f"fps={fps:.1f} steering={steering:+.2f} "\n                    f"steer_pwm={steering_pwm} throttle_pwm={throttle_pwm} "\n                    f"lane_center={lane_center_x} lines={line_count}"\n                )\n\n            elapsed = time.perf_counter() - loop_start\n            target = 1.0 / args.loop_hz\n            if elapsed < target:\n                time.sleep(target - elapsed)\n    except KeyboardInterrupt:\n        print("Interrupted, stopping car.")\n    finally:\n        try:\n            safe_set_pwm(pwm, args.steering_center_pwm, THROTTLE_STOPPED_PWM)\n        except Exception as exc:\n            print(f"Could not send final stop PWM: {exc}")\n        camera.stop()\n        camera.close()\n        print("Car stopped.")\n\n\nif __name__ == "__main__":\n    main()\n', {'build_color_masks'}), ('import ast\nimport csv\nfrom datetime import datetime\nfrom pathlib import Path\n\nimport cv2\nimport numpy as np\n\nbase = Path("offline_results/20260907_124734")\nsource = (base / "source_snapshot.py").read_text()\nold_close = "    white_mask = cv2.morphologyEx(white_mask, cv2.MORPH_CLOSE, kernel)"\nif source.count(old_close) != 1:\n    raise SystemExit("未找到唯一的白色闭运算语句")\nsource = source.replace(old_close, "    # White closing disabled for offline comparison")\nnodes = [\n    n for n in ast.parse(source).body\n    if isinstance(n, ast.FunctionDef)\n    and n.name == "build_color_masks"\n]\nassert len(nodes) == 1\nscope = {"cv2": cv2, "np": np}\nexec(compile(ast.Module(body=nodes, type_ignores=[]),\n             "<vision-only>", "exec"), scope)\n\nwith (base / "results.csv").open(newline="") as f:\n    excluded = {Path(row["image"]).name for row in csv.DictReader(f)}\n\nimport random\npool = sorted(\n    p for p in Path("data/images").glob("*.jpg")\n    if p.name not in excluded\n)\nif len(pool) < 200:\n    raise SystemExit("剩余图片不足200张")\npaths = sorted(random.Random(20260907).sample(pool, 200))\n\noutput = Path("offline_results") / (\n    "validation_v4_" + datetime.now().strftime("%Y%m%d_%H%M%S")\n)\noutput.mkdir(parents=True)\n(output / "test_script.py").write_text(Path(__file__).read_text())\n\ndef segments(mask, y):\n    band = mask[max(0, y-2):min(mask.shape[0], y+3)]\n    xs = np.flatnonzero(np.count_nonzero(band, axis=0) >= 2)\n    if not len(xs):\n        return []\n    groups = np.split(xs, np.where(np.diff(xs) > 1)[0] + 1)\n    return [\n        float(g.mean()) for g in groups\n        if 2 <= len(g) <= mask.shape[1] * 0.18\n    ]\n\ndef white_segments(mask, y):\n    # 单行提取，避免不同高度的白线与背景合并。\n    xs = np.flatnonzero(mask[y] > 0)\n    if not len(xs):\n        return []\n    groups = np.split(xs, np.where(np.diff(xs) > 1)[0] + 1)\n    return [\n        float(g.mean()) for g in groups\n        if 2 <= len(g) <= mask.shape[1] * 0.18\n    ]\n\n# 从近处向远处，每隔画面高度的5%取样。\nratios = np.arange(0.90, 0.549, -0.05)\ntotals = {"selected": 0, "uncertain": 0, "no_track": 0}\ncenter_frames = 0\nfailed = 0\n\nwith (output / "results.csv").open("w", newline="") as f:\n    writer = csv.writer(f)\n    writer.writerow([\n        "image", "track_status", "height_ratio",\n        "white_x", "yellow_x", "center_x"\n    ])\n\n    for path in paths:\n        frame = cv2.imread(str(path))\n        if frame is None:\n            failed += 1\n            continue\n\n        h, w = frame.shape[:2]\n        top = max(0, int(h * 0.55) - 6)\n        white, yellow = scope["build_color_masks"](frame[top:])\n        ys = [max(top, int(round(h * r))) for r in ratios]\n        candidates = [white_segments(white, y-top) for y in ys]\n\n        # 动态规划：寻找跨高度连续的白色候选路径。\n        # 允许跳过一条横带；参数仅用于离线诊断。\n        yellow_candidates = [\n            segments(yellow, y-top) for y in ys\n        ]\n\n        def pair_support(i, x):\n            possible = [\n                left for left in yellow_candidates[i]\n                if 0.15*w <= x-left <= 0.85*w\n            ]\n            # 黄色虚线缺失时不扣分；唯一配对提供少量支持。\n            return 0.35 if len(possible) == 1 else 0.0\n\n        states = {}\n        for i, xs in enumerate(candidates):\n            for j, x in enumerate(xs):\n                support = pair_support(i, x)\n                best = (1.0 + support, [(i, x)])\n                for gap in (1, 2):\n                    prev = i-gap\n                    if prev < 0:\n                        continue\n                    for k, old_x in enumerate(candidates[prev]):\n                        if abs(x-old_x) > 0.14*w*gap:\n                            continue\n                        score, track = states[(prev, k)]\n                        score += 1 - 0.25*abs(x-old_x)/(0.14*w*gap)\n                        score += support\n                        score -= 0.15*(gap-1)\n\n                        # 比较相邻段的横向变化，抑制突然转折。\n                        # 不要求白线必须是直线。\n                        if len(track) >= 2:\n                            earlier_i, earlier_x = track[-2]\n                            old_step = (\n                                (old_x-earlier_x) / (prev-earlier_i)\n                            )\n                            new_step = (x-old_x) / gap\n                            score -= (\n                                0.8 * abs(new_step-old_step) / (0.14*w)\n                            )\n                        if score > best[0]:\n                            best = (score, track+[(i, x)])\n                states[(i, j)] = best\n\n        options = sorted(states.values(), key=lambda t: t[0], reverse=True)\n        options = [\n            item for item in options\n            if len(item[1]) >= 5\n            and item[1][-1][0]-item[1][0][0] >= 4\n        ]\n\n        status = "no_track"\n        chosen = {}\n        if options:\n            score, track = options[0]\n            chosen = dict(track)\n            status = "selected"\n            # 分数接近且位置明显不同的路径视为不确定。\n            for other_score, other_track in options[1:]:\n                if score-other_score > 0.75:\n                    break\n                other = dict(other_track)\n                shared = sorted(chosen.keys() & other.keys())\n                if len(shared) >= 3:\n                    separation = np.median([\n                        abs(chosen[i]-other[i]) for i in shared\n                    ])\n                    if separation > 0.12*w:\n                        status = "uncertain"\n                        chosen = {}\n                        break\n\n        totals[status] += 1\n        view = cv2.resize(frame, (w*4, h*4))\n        centers = 0\n\n        for i, y in enumerate(ys):\n            cv2.line(view, (0, y*4), (w*4-1, y*4),\n                     (80, 80, 80), 1)\n            for x in candidates[i]:\n                cv2.circle(view, (round(x*4), y*4),\n                           3, (140, 140, 140), -1)\n\n            wx = chosen.get(i)\n            yx = ""\n            center = ""\n            if wx is not None:\n                cv2.circle(view, (round(wx*4), y*4),\n                           5, (255, 255, 0), -1)\n                possible = [\n                    x for x in segments(yellow, y-top)\n                    if 0.15*w <= wx-x <= 0.85*w\n                ]\n                for x in possible:\n                    cv2.circle(view, (round(x*4), y*4),\n                               4, (0, 255, 255), -1)\n                if len(possible) == 1:\n                    yx = possible[0]\n                    center = (wx+yx)/2\n                    centers += 1\n                    cv2.circle(view, (round(center*4), y*4),\n                               5, (0, 0, 255), -1)\n\n            writer.writerow([\n                path.name, status, round(float(ratios[i]), 2),\n                wx if wx is not None else "", yx, center\n            ])\n\n        if centers:\n            center_frames += 1\n        cv2.putText(\n            view, f"{status} centers={centers}",\n            (10, 24), cv2.FONT_HERSHEY_SIMPLEX,\n            0.6, (0, 255, 0), 2\n        )\n        if not cv2.imwrite(str(output/path.name), view):\n            raise RuntimeError(f"保存失败: {path.name}")\n\nprint("测试图片:", len(paths))\nprint("读取失败:", failed)\nprint("选出连续白线:", totals["selected"])\nprint("白线存在歧义:", totals["uncertain"])\nprint("未找到足够连续的白线:", totals["no_track"])\nprint("至少有一个候选中心的图片:", center_frames)\nprint("以上均为候选统计，不是准确率")\nprint("结果目录:", output.resolve())\n', {'segments', 'white_segments'})]:
    nodes = [n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name in names]
    assert {n.name for n in nodes} == names
    exec(compile(ast.Module(body=nodes, type_ignores=[]), '<functions>', 'exec'), _SCOPE)

def road_white_segments(mask, value, y):
    xs = np.flatnonzero(mask[y] > 0)
    if not len(xs):
        return []
    groups = np.split(xs, np.where(np.diff(xs) > 1)[0] + 1)
    result = []
    for g in groups:
        if not 2 <= len(g) <= mask.shape[1] * 0.18:
            continue
        left = int(g[0])
        flank = value[y, max(0, left - 7):max(0, left - 1)]
        if len(flank) < 4 or np.mean(flank < 145) < 0.8:
            continue
        result.append(float(g.mean()))
    return result
_SCOPE['road_white_segments'] = road_white_segments
_SCOPE['ratios'] = np.arange(0.9, 0.549, -0.025)
_SCOPE['scope'] = _SCOPE
exec(compile('def detect(frame):\n    h, w = frame.shape[:2]\n    top = max(0, int(h * 0.55) - 6)\n    white, yellow = scope["build_color_masks"](frame[top:])\n    context_top = max(0, top-3)\n    white = scope["build_color_masks"](frame[context_top:])[0][top-context_top:]\n    ys = [max(top, int(round(h * r))) for r in ratios]\n    value = cv2.cvtColor(frame[top:], cv2.COLOR_BGR2HSV)[:, :, 2]\n    candidates = [road_white_segments(white, value, y-top) for y in ys]\n\n    # 动态规划：寻找跨高度连续的白色候选路径。\n    # 允许跳过一条横带；参数仅用于离线诊断。\n    yellow_candidates = [\n        segments(yellow, y-top) for y in ys\n    ]\n\n    def pair_support(i, x):\n        possible = [\n            left for left in yellow_candidates[i]\n            if 0.15*w <= x-left <= 0.85*w\n        ]\n        # 黄色虚线缺失时不扣分；唯一配对提供少量支持。\n        return 0.35 if len(possible) == 1 else 0.0\n\n    states = {}\n    for i, xs in enumerate(candidates):\n        for j, x in enumerate(xs):\n            support = .5 * pair_support(i, x)\n            best = (1.0 + support, [(i, x)])\n            for gap in (1, 2, 3, 4):\n                prev = i-gap\n                if prev < 0:\n                    continue\n                for k, old_x in enumerate(candidates[prev]):\n                    if abs(x-old_x) > 0.14*w*(gap/2):\n                        continue\n                    score, track = states[(prev, k)]\n                    score += .5 - 0.25*abs(x-old_x)/(0.14*w*(gap/2))\n                    score += support\n                    score -= 0.15*max(0, gap/2-1)\n\n                    # 比较相邻段的横向变化，抑制突然转折。\n                    # 不要求白线必须是直线。\n                    if len(track) >= 2:\n                        earlier_i, earlier_x = track[-2]\n                        old_step = (\n                            (old_x-earlier_x) / ((prev-earlier_i)/2)\n                        )\n                        new_step = (x-old_x) / (gap/2)\n                        score -= (\n                            0.8 * abs(new_step-old_step) / (0.14*w)\n                        )\n                    if score > best[0]:\n                        best = (score, track+[(i, x)])\n            states[(i, j)] = best\n\n    options = sorted(states.values(), key=lambda t: t[0], reverse=True)\n    options = [\n        item for item in options\n        if len(item[1]) >= 9\n        and item[1][-1][0]-item[1][0][0] >= 8\n    ]\n\n    status = "no_track"\n    chosen = {}\n    if options:\n        score, track = options[0]\n        chosen = dict(track)\n        status = "selected"\n        global audit_options\n        audit_options = [item for item in options if score-item[0] <= .75]\n    else:\n        audit_options = []\n\n    return status, chosen, ys, yellow\n', '<detector>', 'exec'), _SCOPE)

def target(points, y):
    for py, x in points:
        if abs(py - y) < 1e-06:
            return (x, 'direct')
    above = [p for p in points if p[0] < y]
    below = [p for p in points if p[0] > y]
    if above and below:
        y0, x0 = above[-1]
        y1, x1 = below[0]
        if y1 - y0 <= 0.15 + 1e-06:
            return (x0 + (y - y0) / (y1 - y0) * (x1 - x0), 'interpolated')
    return (None, 'unavailable')

def control(points, width, track_status='selected'):
    near, near_status = target(points, 0.65)
    result = dict(near_x=near, near_status=near_status, far_x=None, far_y=None, far_status='unavailable', near_offset=None, preview_error=None, steering_pwm=365, control_status='unavailable')
    if track_status != 'selected' or near is None:
        return result
    near_offset = (near - width / 2) / (width / 2)
    result['near_offset'] = near_offset
    for y in (0.55, 0.6):
        far, far_status = target(points, y)
        if far is not None:
            break
    if far is None:
        return result
    far_offset = (far - width / 2) / (width / 2)
    trend = (far_offset - near_offset) * (0.1 / (0.65 - y))
    preview = float(np.clip(near_offset + 1.5 * trend, -1, 1))
    command = int(round(365 - 75 * float(np.clip(preview / 0.5, -1, 1))))
    result.update(far_x=far, far_y=y, far_status=far_status, preview_error=preview, steering_pwm=command, control_status='ready')
    return result

def consistent_pairs(frame, chosen, ys, yellow):
    h, w = frame.shape[:2]
    top = max(0, int(h * 0.55) - 6)
    value = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)[:, :, 2]
    nodes = []
    rejected = []
    for i, wx in chosen.items():
        y = ys[i]
        for yx in _SCOPE['segments'](yellow, y - top):
            if not 0.15 * w <= wx - yx <= 0.85 * w:
                continue
            lo = int(np.ceil(yx)) + 3
            hi = int(np.floor(wx)) - 3
            strip = value[y, lo:hi]
            if len(strip) < 8 or np.mean(strip < 145) < 0.9:
                rejected.append((y / h, (wx + yx) / 2, 'bright_interior'))
                continue
            nodes.append((i, yx, wx, float(np.mean(strip < 145))))
    nodes.sort()
    paths = []
    for j, node in enumerate(nodes):
        i, yx, wx, quality = node
        options = [(1.0 + 0.1 * quality, [j])]
        for score, path in paths:
            pi, pyx, pwx, pquality = nodes[path[-1]]
            gap = (i - pi) / 2
            if not 0.5 <= gap <= 3:
                continue
            if abs(yx - pyx) > 0.14 * w * gap or abs(wx - pwx) > 0.14 * w * gap:
                continue
            if wx - yx - (pwx - pyx) > 0.025 * w * gap:
                continue
            score = score + 1.0 + 0.1 * quality - 0.1 * (gap - 1)
            options.append((score, path + [j]))
        paths.extend(sorted(options, key=lambda x: x[0], reverse=True)[:4])
    viable = [p for p in paths if len(p[1]) >= 3 and nodes[p[1][-1]][0] - nodes[p[1][0]][0] >= 6]
    if not viable:
        return ([], 'insufficient_pairs', rejected)
    viable.sort(key=lambda x: x[0], reverse=True)
    score, path = viable[0]
    selected = {nodes[j][0]: (nodes[j][1] + nodes[j][2]) / 2 for j in path}
    for other_score, other_path in viable[1:]:
        if score - other_score > 0.5:
            break
        other = {nodes[j][0]: (nodes[j][1] + nodes[j][2]) / 2 for j in other_path}
        shared = selected.keys() & other.keys()
        if len(shared) >= 2 and np.median([abs(selected[i] - other[i]) for i in shared]) > 0.08 * w:
            return ([], 'ambiguous_pairs', rejected)
    return (sorted(((ys[i] / h, x) for i, x in selected.items())), 'consistent', rejected)

def analyze(frame):
    status, chosen, ys, yellow = _SCOPE['detect'](frame)
    points, pair_status, rejected = consistent_pairs(frame, chosen, ys, yellow)
    result = control(points, frame.shape[1], status)
    result.update(track_status=status, points=points, chosen=chosen, ys=ys, pair_status=pair_status, rejected=rejected)
    return result
'Offline-only edge audit. No hardware imports or driving entry point.'
import cv2
import numpy as np
original_analyze = analyze
raw_white = None

def road_white_segments(mask, value, y):
    xs = np.flatnonzero(mask[y] > 0)
    if not len(xs):
        return []
    result = []
    for g in np.split(xs, np.where(np.diff(xs) > 1)[0] + 1):
        if not 2 <= len(g) <= mask.shape[1] * 0.18:
            continue
        left = int(g[0])
        edge = left
        bridged = False
        while edge > 0 and left - edge < 6:
            if raw_white[y, edge - 1]:
                edge -= 1
            elif not bridged and edge >= 3 and (left - edge <= 3) and raw_white[y, edge - 2] and raw_white[y, edge - 3]:
                edge -= 3
                bridged = True
            else:
                break
        flank = value[y, max(0, edge - 7):max(0, edge - 1)]
        if len(flank) < 4 or np.mean(flank < 145) < 0.8:
            continue
        result.append(float(g.mean()))
    return result

def analyze(frame):
    global raw_white
    top = max(0, int(frame.shape[0] * 0.55) - 6)
    hsv = cv2.cvtColor(frame[top:], cv2.COLOR_BGR2HSV)
    raw_white = cv2.inRange(hsv, np.array([0, 0, 145]), np.array([179, 80, 255]))
    original = _SCOPE['road_white_segments']
    _SCOPE['road_white_segments'] = road_white_segments
    try:
        return original_analyze(frame)
    finally:
        _SCOPE['road_white_segments'] = original
'Offline experiment only: horizontal white opening.'
import cv2
import numpy as np
_edge_analyze = analyze

def analyze(frame):
    original = _SCOPE['build_color_masks']

    def masks(roi):
        _, yellow = original(roi)
        hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
        white = cv2.inRange(hsv, np.array([0, 0, 145]), np.array([179, 80, 255]))
        white = cv2.morphologyEx(white, cv2.MORPH_OPEN, np.ones((1, 3), np.uint8))
        return (white, yellow)
    _SCOPE['build_color_masks'] = masks
    try:
        return _edge_analyze(frame)
    finally:
        _SCOPE['build_color_masks'] = original

_dense_analyze = analyze

def analyze(frame):
    # Initialize masks and preserve all existing detector/color behavior.
    initial = _dense_analyze(frame)
    options = _SCOPE.get('audit_options', [])
    if not options:
        return initial
    if len(options) > 64:
        result = control([], frame.shape[1], 'uncertain')
        result.update(track_status='uncertain', pair_status='candidate_limit', points=[], chosen={}, ys=initial['ys'], rejected=[])
        return result
    _, _, ys, yellow = _SCOPE['detect'](frame)
    valid = []
    for score, track in options:
        points, status, rejected = consistent_pairs(frame, dict(track), ys, yellow)
        if status == 'consistent':
            valid.append((points, dict(track), rejected))
    if not valid:
        result = control([], frame.shape[1], 'uncertain')
        result.update(track_status='uncertain', pair_status='no_valid_path', points=[], chosen={}, ys=ys, rejected=[])
        return result
    points, chosen, rejected = valid[0]
    reference = dict(points)
    for other, _, _ in valid[1:]:
        alternate = dict(other)
        shared = reference.keys() & alternate.keys()
        # Insufficient common support cannot establish equivalence.
        if len(shared) < 2 or np.median([abs(reference[y]-alternate[y]) for y in shared]) > .08*frame.shape[1]:
            result = control([], frame.shape[1], 'uncertain')
            result.update(track_status='uncertain', pair_status='ambiguous_valid_paths', points=[], chosen={}, ys=ys, rejected=[])
            return result
    result = control(points, frame.shape[1], 'selected')
    result.update(track_status='selected', pair_status='consistent', points=points, chosen=chosen, ys=ys, rejected=rejected)
    return result

"""Offline independent-boundary prototype. Never controls hardware."""
import cv2
import numpy as np
_independent_base_analyze = analyze

def analyze(frame):
    original=_independent_base_analyze(frame)
    if original['control_status']=='ready':return original
    options=_SCOPE.get('audit_options',[])
    if not options or len(options)>64:return original
    h,w=frame.shape[:2];top=max(0,int(h*.55)-6)
    _,yellow=_SCOPE['build_color_masks'](frame[top:])
    value=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)[:,:,2]
    anchors=[]
    # Independent yellow samples; retain ambiguous rows as missing evidence.
    for row in range(int(h*.55),int(h*.9)+1):
        xs=[x for x in _SCOPE['segments'](yellow,row-top) if x < .65*w]
        if len(xs)==1:anchors.append((row/h,xs[0]))
    if len(anchors)<8:return original
    a=np.array(anchors);yy=a[:,0];xx=a[:,1]
    if np.ptp(yy)<.20:return original
    coef=np.polyfit(yy,xx,2)
    residual=abs(np.polyval(coef,yy)-xx)
    inliers=residual<=.025*w
    if np.mean(inliers)<.9 or np.count_nonzero(inliers)<8:return original
    if not np.all(inliers):
        coef=np.polyfit(yy[inliers],xx[inliers],2)
        if max(abs(np.polyval(coef,yy[inliers])-xx[inliers]))>.025*w:return original
        yy=yy[inliers];xx=xx[inliers]
        if np.ptp(yy)<.20:return original
    results=[]
    _,_,ys,_=_SCOPE['detect'](frame)
    for _,track in options:
        wp=sorted((ys[i]/h,x) for i,x in track)
        miny=max(yy.min(),wp[0][0]);maxy=min(yy.max(),wp[-1][0])
        if miny>.60 or maxy<.65:continue
        points=[]
        for y,wx in wp:
            if not miny<=y<=maxy:continue
            yx=float(np.polyval(coef,y));width=wx-yx
            if not .15*w<=width<=.85*w:continue
            strip=value[round(y*h),max(0,int(np.ceil(yx))+3):int(np.floor(wx))-3]
            if len(strip)<8 or np.mean(strip<145)<.9:continue
            points.append((y,(wx+yx)/2))
        if len(points)<4:continue
        r=control(points,w,'selected')
        if r['control_status']=='ready':
            r['points']=points;results.append(r)
    if not results:return original
    first=results[0]
    for other in results[1:]:
        y=max(first['far_y'],other['far_y'])
        ax,_=target(first['points'],y);bx,_=target(other['points'],y)
        if ax is None or bx is None or abs(ax-bx)>.04*w or abs(first['near_x']-other['near_x'])>.04*w:return original
    result=dict(original);result.update(first);result['target_source']='independent_estimated'
    result['near_status']=result['far_status']='estimated'
    return result

"""Offline uncertainty-bounded local center fit; experimental, not a driver."""
import numpy as np
import cv2
_local_base_analyze = analyze

def analyze(frame):
    original=_local_base_analyze(frame)
    if original['control_status']=='ready':return original
    options=_SCOPE.get('audit_options',[])
    if not options or len(options)>64:return original
    h,w=frame.shape[:2];top=max(0,int(h*.55)-6)
    _,_,ys,yellow=_SCOPE['detect'](frame)
    value=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)[:,:,2];valid=[]
    for _,track in options:
        points=[]
        for i,wx in track:
            y=ys[i]/h
            if not .55<=y<=.85:continue
            good=[]
            for yx in _SCOPE['segments'](yellow,ys[i]-top):
                if not .15*w<=wx-yx<=.85*w:continue
                strip=value[ys[i],int(np.ceil(yx))+3:int(np.floor(wx))-3]
                if len(strip)>=8 and np.mean(strip<145)>=.9:good.append((wx+yx)/2)
            if len(good)==1:points.append((y,good[0]))
        if len(points)<3:continue
        a=np.array(points);yy=a[:,0];xx=a[:,1]
        span=np.ptp(yy)
        if span<.05-1e-6:continue
        extrap=max(yy.min()-.65,.65-yy.max(),0)
        if extrap>.05+1e-6:continue
        fit=np.polyfit(yy,xx,1);res=xx-np.polyval(fit,yy)
        if max(abs(res))>1.5:continue
        noise=max(.5,float(np.sqrt(np.sum(res**2)/max(1,len(xx)-2))))
        spread=np.sum((yy-yy.mean())**2)
        near_uncertainty=noise*np.sqrt(1/len(xx)+(.65-yy.mean())**2/spread)
        slope_uncertainty=noise/np.sqrt(spread)
        if near_uncertainty>1.5 or 150*1.5*.1*slope_uncertainty/(w/2)>8:continue
        near=float(np.polyval(fit,.65))
        offset=(near-w/2)/(w/2)
        preview=float(np.clip(offset-1.5*.1*fit[0]/(w/2),-1,1))
        # Do not introduce saturated steering from this new estimation branch.
        if abs(preview)>=.5:continue
        valid.append(dict(near_x=near,near_offset=offset,preview_error=preview,steering_pwm=int(round(365-75*float(np.clip(preview/.5,-1,1)))),model_points=sorted(points),near_extrapolation=extrap,near_uncertainty_px=near_uncertainty))
    if not valid:return original
    best=valid[0]
    if any(abs(x['near_x']-best['near_x'])>.04*w or abs(x['preview_error']-best['preview_error'])>.08 for x in valid[1:]):return original
    result=dict(original);result.update(best);result.update(control_status='ready',target_source='local_geometry_estimated',near_status='estimated',far_status='unavailable',far_x=None,far_y=None,pair_status='local_geometry_estimated',points=best['model_points'])
    return result
