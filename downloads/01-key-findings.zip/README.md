# Key Findings Pack

Start here for the three central findings and their supporting chart data.

## Contents

- `original-chinese/OpenCV-stage-report.md` — Original OpenCV development and completed-lap report.
- `english/OpenCV-stage-report-EN.md` — Evidence-preserving English reading edition.
- `original-chinese/phone-comparison-report.md` — Original phone-timed comparison report.
- `english/phone-comparison-report-EN.md` — English reading edition of the timed comparison.
- `original-chinese/reviewed-pixel-evaluation.md` — Original reviewed pixel-offset evaluation.
- `english/reviewed-pixel-evaluation-EN.md` — English reading edition of the reviewed evaluation.
- `chart-data/phone-comparison.json` — Values used by the lap-time chart.
- `chart-data/pixel-summary.json` — Values used by the pixel-error chart.

## Reading notes

- English report editions are provided for accessibility. The original Chinese records remain included when relevant.
- Review the limitations stated in each report before comparing methods.
- This package contains selected research material. The website archive retains the complete provenance record.
