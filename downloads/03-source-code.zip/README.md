# Source Code Pack

The six clearly named Python programs from the public project script directory.

## Contents

- `python/create_loss_stop_test.py` — Creates the target-loss stop test.
- `python/create_steering_vision_test.py` — Creates the steering and vision test.
- `python/create_straight_400_test.py` — Creates the straight-driving PWM 400 test.
- `python/opencv_drive_car.py` — Main OpenCV vehicle control program.
- `python/opencv_lane_detection.py` — OpenCV lane-detection implementation.
- `python/outer_lane_color_detection.py` — Outer lane colour-detection utility.

## Reading notes

- English report editions are provided for accessibility. The original Chinese records remain included when relevant.
- Review the limitations stated in each report before comparing methods.
- This package contains selected research material. The website archive retains the complete provenance record.
